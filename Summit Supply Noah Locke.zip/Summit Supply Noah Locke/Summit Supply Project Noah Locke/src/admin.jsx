import React from 'react';
import { useStore } from './StoreContext.jsx';

export default function Admin() {
  const { products, coupons, addProduct, addCoupon } = useStore();

  function saveProduct(event) {
    event.preventDefault();

    const form = event.currentTarget;
    const fields = new FormData(form);
    const name = fields.get('title').trim();
    const category = fields.get('category').trim();

    if (!name || !category) {
      alert('Enter a product title and category.');
      return;
    }

    const product = {
      id: crypto.randomUUID(),
      name,
      category,
      image: fields.get('image').trim(),
      price: Number(fields.get('price')),
      icon: '🏕️',
    };

    addProduct(product);
    form.reset();
  }

  function saveCoupon(event) {
    event.preventDefault();

    const form = event.currentTarget;
    const fields = new FormData(form);
    const code = fields.get('code').trim().toUpperCase();

    if (!code) {
      alert('Enter a coupon code.');
      return;
    }

    const coupon = {
      code,
      discount: Number(fields.get('discount')),
    };

    if (!addCoupon(coupon)) {
      alert('That coupon code already exists.');
      return;
    }
    form.reset();
  }

  return (
    <section className="page">
      <p className="eyebrow">Summit Supply</p>
      <h1>Store Administration</h1>
      <p>Add products and create discount codes for the store.</p>

      <div className="about-grid">
        <section>
          <h2>Add Products</h2>

          <form className="panel contact-form" onSubmit={saveProduct}>
            <label htmlFor="product-title">Title</label>
            <input id="product-title" name="title" required />

            <label htmlFor="product-category">Category</label>
            <input id="product-category" name="category" required />

            <label htmlFor="product-image">Image URL</label>
            <input
              id="product-image"
              name="image"
              type="url"
              placeholder="https://example.com/product.jpg (optional)"
            />

            <label htmlFor="product-price">Price ($)</label>
            <input
              id="product-price"
              name="price"
              type="number"
              min="0"
              step="0.01"
              required
            />

            <button className="button" type="submit">Save Product</button>
          </form>

          <h3>Products List</h3>
          <p className="admin-helper">Includes catalog items and products you add here.</p>

          <div className="admin-list">
            {products.map((product) => (
              <article className="panel admin-product" key={product.id}>
                {product.image ? <img src={product.image} alt={product.name} /> : <span className="admin-icon" aria-hidden="true">{product.icon || '🏕️'}</span>}
                <div>
                  <strong>{product.name}</strong>
                  <p>{product.category} · ${product.price.toFixed(2)}</p>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section>
          <h2>Add Coupons</h2>

          <form className="panel contact-form" onSubmit={saveCoupon}>
            <label htmlFor="coupon-code">Code</label>
            <input
              id="coupon-code"
              name="code"
              placeholder="TRAIL20"
              required
            />

            <label htmlFor="coupon-discount">Discount (%)</label>
            <input
              id="coupon-discount"
              name="discount"
              type="number"
              min="1"
              max="100"
              step="1"
              required
            />

            <button className="button" type="submit">Save Coupon</button>
          </form>

          <h3>Coupons List</h3>
          {coupons.length === 0 && <p>No coupons added yet.</p>}

          <ul className="admin-list admin-coupons">
            {coupons.map((coupon) => (
              <li className="panel" key={coupon.code}>
                <strong>{coupon.code}</strong> · {coupon.discount}% off
              </li>
            ))}
          </ul>
        </section>
      </div>
    </section>
  );
}