import React, { useState } from 'react';
import { Link, NavLink, Route, Routes } from 'react-router-dom';
import Admin from './admin.jsx';
import Cart from './Cart.jsx';
import { getCategories } from './services/dataService.js';
import { useStore } from './StoreContext.jsx';

function Navbar() {
  const { user, cartCount } = useStore();

  return (
    <header className="site-header">
      <Link className="brand" to="/">▲ Summit Supply</Link>

      <nav aria-label="Main navigation">
        <NavLink to="/" end>Home</NavLink>
        <NavLink to="/catalog">Catalog</NavLink>
        <NavLink to="/about">About</NavLink>
        <NavLink to="/contact">Contact</NavLink>
        <NavLink to="/admin">Admin</NavLink>
        <NavLink to="/cart">Cart ({cartCount})</NavLink>

        <span className="nav-account" aria-live="polite">
          Hi, {user.name}
        </span>
      </nav>
    </header>
  );
}

function Home() {
  return (
    <section className="hero">
      <div className="hero-copy">
        <p className="eyebrow">The Weekend Collection</p>
        <h1>Take the long way.</h1>
        <p>Simple outdoor gear for the days you’d rather spend outside.</p>
        <Link className="button" to="/catalog">Explore the catalog →</Link>
      </div>

      <svg
        className="mountains"
        viewBox="0 0 500 320"
        preserveAspectRatio="xMidYMid slice"
        aria-hidden="true"
      >
        <rect width="500" height="320" fill="#b7c8b1" />
        <circle cx="370" cy="90" r="48" fill="#f5bb69" />
        <path d="M0 270 115 125 190 215 320 70 500 265V320H0Z" fill="#789784" />
        <path d="M0 285 145 190 230 265 370 145 500 248V320H0Z" fill="#406d59" />
        <path d="M0 305 145 255 255 300 405 225 500 270V320H0Z" fill="#224c3c" />
      </svg>
    </section>
  );
}

function Catalog() {
  const [category, setCategory] = useState('All');
  const { products, addToCart } = useStore();
  const categories = getCategories(products);

  const visibleProducts = products.filter(
    (product) => category === 'All' || product.category === category
  );

  return (
    <section className="page">
      <p className="eyebrow">The Gear Room</p>
      <h1>Catalog</h1>
      <p>Find your essentials for a morning hike or a weekend away.</p>

      <div className="filters" role="group" aria-label="Product categories">
        {categories.map((item) => (
          <button
            key={item}
            type="button"
            aria-pressed={category === item}
            onClick={() => setCategory(item)}
          >
            {item}
          </button>
        ))}
      </div>

      <div className="product-grid">
        {visibleProducts.map((product) => (
          <article className="card" key={product.id}>
            <div className="product-art">
              <span className="product-image-fallback" aria-hidden="true">{product.icon || '🏕️'}</span>
              {product.image && (
                <img
                  className="catalog-image"
                  src={product.image}
                  alt={`${product.name} product photo`}
                  loading="lazy"
                  onError={(event) => { event.currentTarget.style.display = 'none'; }}
                />
              )}
            </div>

            <div className="card-copy">
              <p className="eyebrow">{product.category}</p>
              <h2>{product.name}</h2>
              <strong>${product.price.toFixed(2)}</strong>

              <div>
                <button
                  className="button"
                  type="button"
                  onClick={() => addToCart(product)}
                >
                  Add to Cart
                </button>
              </div>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

function About() {
  return (
    <section className="page">
      <p className="eyebrow">Our Story</p>
      <h1>About Summit Supply</h1>
      <p>Summit Supply is a concept shop inspired by coastal trails and spontaneous weekend trips.</p>

      <div className="about-grid">
        <article className="panel">
          <h2>Pack light</h2>
          <p>We focus on gear that’s easy to carry and useful on more than one kind of trip.</p>
        </article>

        <article className="panel">
          <h2>Get outside</h2>
          <p>Our catalog is built for anyone making time outdoors, from first-time hikers to weekend regulars.</p>
        </article>
      </div>

      <Link className="button" to="/catalog">Browse the gear →</Link>
    </section>
  );
}

function Contact() {
  const [submitted, setSubmitted] = useState(false);

  function handleSubmit(event) {
    event.preventDefault();
    event.currentTarget.reset();
    setSubmitted(true);
  }

  return (
    <section className="page">
      <p className="eyebrow">Say Hello</p>
      <h1>Contact</h1>
      <p>Have a question about the gear or an idea for the shop?</p>

      <form
        className="panel contact-form"
        onSubmit={handleSubmit}
        onChange={() => setSubmitted(false)}
      >
        <label htmlFor="name">Name</label>
        <input id="name" name="name" autoComplete="name" required />

        <label htmlFor="email">Email</label>
        <input id="email" name="email" type="email" autoComplete="email" required />

        <label htmlFor="message">Message</label>
        <textarea id="message" name="message" rows="5" required />

        <button className="button" type="submit">Submit demo message</button>

        <div role="status">
          {submitted && <p className="notice">Thanks! Your demo submission is complete.</p>}
        </div>
      </form>
    </section>
  );
}

function NotFound() {
  return (
    <section className="page lost">
      <p className="eyebrow">404 · Off the Trail</p>
      <h1>Trail ends here.</h1>
      <p>We couldn’t find that page.</p>
      <Link className="button" to="/">← Back to Home</Link>
    </section>
  );
}

export default function App() {
  return (
    <>
      <Navbar />

      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/catalog" element={<Catalog />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/admin" element={<Admin />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>

      <footer className="site-footer">
        Summit Supply · Outdoor Gear Concept Shop
      </footer>
    </>
  );
}