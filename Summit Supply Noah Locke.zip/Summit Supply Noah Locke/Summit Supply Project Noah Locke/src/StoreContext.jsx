import React, { createContext, useContext, useState } from 'react';
import { getProducts } from './services/dataService.js';

const StoreContext = createContext(null);
const STORAGE_KEY = 'summit-supply-store-v1';

function loadSavedStore() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null');
    if (saved && Array.isArray(saved.products) && Array.isArray(saved.cart) && Array.isArray(saved.coupons)) {
      const seed = getProducts();
      const byId = new Map(seed.map((product) => [product.id, product]));
      // Update the photos for original products without deleting any Admin-added products.
      return {
        ...saved,
        products: saved.products.map((product) =>
          byId.has(product.id) ? { ...product, image: byId.get(product.id).image } : product
        ),
        cart: saved.cart.map((item) =>
          byId.has(item.id) ? { ...item, image: byId.get(item.id).image } : item
        ),
      };
    }
  } catch { /* Ignore invalid or unavailable storage. */ }
  return { products: getProducts(), cart: [], coupons: [] };
}

export function StoreProvider({ children }) {
  const [user] = useState({ name: 'Noah' });
  const [store, setStore] = useState(loadSavedStore);
  const { products, cart, coupons } = store;

  function updateStore(updater) {
    setStore((previous) => {
      const next = updater(previous);
      try { localStorage.setItem(STORAGE_KEY, JSON.stringify(next)); } catch { /* Browser storage may be unavailable. */ }
      return next;
    });
  }

  function addToCart(product) {
    updateStore((previous) => {
      const existing = previous.cart.find((item) => item.id === product.id);
      const cart = existing
        ? previous.cart.map((item) => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item)
        : [...previous.cart, { ...product, quantity: 1 }];
      return { ...previous, cart };
    });
  }

  function updateQuantity(productId, quantity) {
    const safeQuantity = Math.max(0, Math.floor(Number(quantity) || 0));
    updateStore((previous) => ({
      ...previous,
      cart: previous.cart
        .map((item) => item.id === productId ? { ...item, quantity: safeQuantity } : item)
        .filter((item) => item.quantity > 0),
    }));
  }

  function removeFromCart(productId) {
    updateStore((previous) => ({ ...previous, cart: previous.cart.filter((item) => item.id !== productId) }));
  }

  function addProduct(product) {
    updateStore((previous) => ({ ...previous, products: [...previous.products, product] }));
  }

  function addCoupon(coupon) {
    if (coupons.some((item) => item.code === coupon.code)) return false;
    updateStore((previous) => ({ ...previous, coupons: [...previous.coupons, coupon] }));
    return true;
  }

  const cartCount = cart.reduce((total, item) => total + item.quantity, 0);
  const cartTotal = cart.reduce((total, item) => total + item.price * item.quantity, 0);

  return (
    <StoreContext.Provider value={{
      user, products, coupons, cart, cartCount, cartTotal,
      addToCart, updateQuantity, removeFromCart, addProduct, addCoupon,
    }}>
      {children}
    </StoreContext.Provider>
  );
}

export function useStore() {
  const store = useContext(StoreContext);
  if (store === null) throw new Error('useStore must be used inside StoreProvider.');
  return store;
}
