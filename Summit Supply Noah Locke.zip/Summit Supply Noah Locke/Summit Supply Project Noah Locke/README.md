# Summit Supply — Complete Online Store Assignment

React + Vite course project. All six pages: Home, Catalog, About, Contact, Admin, Cart.

## Run on Windows in VS Code
1. Extract this ZIP (do not open an old `myreactstore` folder).
2. Open the extracted `Summit-Supply-Completed` folder in VS Code.
3. Run `npm install` in its terminal.
4. Run `npm run dev` and open the Local URL (usually http://localhost:5173).

## Try the features
- Catalog: filter and add items to the cart.
- Navbar: shows cart count and links to the cart.
- Cart: change quantities, remove items, view line totals and overall total.
- Admin: create products and coupon codes; new products show in the catalog.
- Product data comes from `src/services/dataService.js`.
- Products, coupons and cart contents persist in browser localStorage for this frontend demo.

This is a frontend-only course demo: contact messages do not send, coupon codes are managed/listed but not applied at checkout, and purchases are not processed. If your FSDI 107 course provided a specific backend `dataService.js`, replace the seed-data service with that implementation.


## Real product photos

The six starter catalog items now use **photos of real corresponding categories of outdoor gear** (backpack, flask, rain shell, baseball cap, headlamp, and hip pack). The Summit Supply names and prices remain demo information, not claims about the pictured third-party products. Images are loaded from third-party product websites and need an internet connection. Their owners may change or remove the image URLs. If one fails, an emoji fallback will show.

The product image URLs are in `src/services/dataService.js`. Existing saved carts and products automatically receive the new starter item photos, while Admin-added products are preserved.
