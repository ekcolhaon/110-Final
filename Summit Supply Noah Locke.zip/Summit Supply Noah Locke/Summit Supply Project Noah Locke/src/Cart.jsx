import React from 'react';
import { Link } from 'react-router-dom';
import { useStore } from './StoreContext.jsx';

const money = (amount) => `$${amount.toFixed(2)}`;

export default function Cart() {
  const { cart, cartCount, cartTotal, updateQuantity, removeFromCart } = useStore();

  return (
    <section className="page">
      <p className="eyebrow">Your Gear Bag</p>
      <h1>Shopping Cart</h1>
      <p>Review your items before your next adventure.</p>

      {cart.length === 0 ? (
        <div className="panel empty-cart">
          <h2>Your cart is empty.</h2>
          <p>Find something for the trail in our catalog.</p>
          <Link className="button" to="/catalog">Explore the catalog →</Link>
        </div>
      ) : (
        <>
          <div className="cart-items">
            {cart.map((item) => (
              <article className="panel cart-item" key={item.id}>
                <div className="cart-art">
                  <span className="product-image-fallback" aria-hidden="true">{item.icon || '🎒'}</span>
                  {item.image && <img src={item.image} alt={`${item.name} product photo`} onError={(event) => { event.currentTarget.style.display = 'none'; }} />}
                </div>
                <div className="cart-detail">
                  <p className="eyebrow">{item.category}</p>
                  <h2>{item.name}</h2>
                  <p>Unit price: {money(item.price)}</p>
                  <div className="quantity-actions">
                    <label htmlFor={`qty-${item.id}`}>Quantity</label>
                    <button type="button" aria-label={`Decrease ${item.name} quantity`} onClick={() => updateQuantity(item.id, item.quantity - 1)}>−</button>
                    <input id={`qty-${item.id}`} type="number" min="1" max="999" value={item.quantity} onChange={(event) => { if (event.target.value !== '') updateQuantity(item.id, Math.min(999, Math.max(1, Number(event.target.value)))); }} />
                    <button type="button" aria-label={`Increase ${item.name} quantity`} onClick={() => updateQuantity(item.id, Math.min(999, item.quantity + 1))}>+</button>
                    <button className="remove-button" type="button" onClick={() => removeFromCart(item.id)}>Remove</button>
                  </div>
                </div>
                <strong className="line-price">{money(item.price * item.quantity)}</strong>
              </article>
            ))}
          </div>
          <div className="panel cart-summary">
            <h2>Order Summary</h2>
            <div className="summary-line"><span>Items</span><strong>{cartCount}</strong></div>
            <div className="summary-line"><span>Subtotal</span><strong>{money(cartTotal)}</strong></div>
            <div className="summary-line summary-total"><span>Total</span><strong>{money(cartTotal)}</strong></div>
            <p className="cart-note">Demo store only — no payment or checkout is processed.</p>
            <Link className="button" to="/catalog">Continue shopping</Link>
          </div>
        </>
      )}
    </section>
  );
}
