// Catalog sample products. These are Summit Supply demo names and prices.
// Photos show real outdoor products of the same type, used as visual references;
// the pictured brands/products are not claimed to be sold by Summit Supply.
// Images are served from external websites, so internet access is required.
const seedProducts = [
  { id: 1, name: 'Ridgeline Daypack', category: 'Packs', price: 64, icon: '🎒', image: 'https://pisces.bbystatic.com/image2/BestBuy_US/images/products/2cab79d4-09c0-46db-ba17-fb0112bf5847.jpg%3BmaxHeight%3D1920%3BmaxWidth%3D900?format=webp' },
  { id: 2, name: 'Switchback Flask', category: 'Accessories', price: 28, icon: '💧', image: 'https://ajantashoes.com/cdn/shop/files/WB0025_3_580a67bd-e5eb-4108-88a8-0715d4a25f08.jpg?v=1767180680&width=4167' },
  { id: 3, name: 'Coastline Shell', category: 'Apparel', price: 89, icon: '🧥', image: 'https://media-www.atmosphere.ca/product/div-03-softgoods/dpt-76-outerwear/sdpt-01-mens/333775232/or-mens-motive-ascentshell-3l-rain-shell-f21-blu-26cca349-717c-45f9-94c0-705901901c07-jpgrendition.jpg' },
  { id: 4, name: 'Trail Marker Cap', category: 'Apparel', price: 24, icon: '🧢', image: 'https://images.hardloop.fr/1176392-large_default/mountain-equipment-beris-cap-cap.jpg' },
  { id: 5, name: 'Dusk Headlamp', category: 'Accessories', price: 36, icon: '🔦', image: 'https://www.naturehike.com/cdn/shop/files/71nfaBl8uIL._AC_SX679.jpg?v=1753173514' },
  { id: 6, name: 'Overlook Hip Pack', category: 'Packs', price: 38, icon: '🧭', image: 'https://m.media-amazon.com/images/I/71SOuWUkDaL.jpg' },
];

export function getProducts() {
  return seedProducts.map((product) => ({ ...product }));
}

export function getCategories(products = getProducts()) {
  return ['All', ...new Set(products.map((product) => product.category))];
}
